﻿using ManageEmployee.Models;

namespace ManageEmployee.ViewModels
{
    public class HomeDetailsViewModel
    {
        public Employee Employee { get; set; }
        public string PageTitle { get; set; }
    }
}
